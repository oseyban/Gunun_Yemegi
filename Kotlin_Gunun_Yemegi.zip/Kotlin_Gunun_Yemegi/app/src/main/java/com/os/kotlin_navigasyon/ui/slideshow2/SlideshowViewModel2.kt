package com.os.kotlin_navigasyon.ui.slideshow2

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SlideshowViewModel2 : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Bu alan Diğer Bölümler-2 i içerir"
    }
    val text: LiveData<String> = _text
}