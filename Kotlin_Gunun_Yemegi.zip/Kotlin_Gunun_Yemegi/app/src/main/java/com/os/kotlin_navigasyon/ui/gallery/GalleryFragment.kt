package com.os.kotlin_navigasyon.ui.gallery

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.os.kotlin_navigasyon.R
import com.os.kotlin_navigasyon.databinding.FragmentGalleryBinding
import java.io.ByteArrayOutputStream

@Suppress("DEPRECATION")
class GalleryFragment : Fragment() {

    var secilenGorsel : Uri?=null
    var secilenBitmap : Bitmap?=null

    private var _binding: FragmentGalleryBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val galleryViewModel =
            ViewModelProvider(this).get(GalleryViewModel::class.java)

        _binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textGallery
        galleryViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val button1 = view.findViewById<Button>(R.id.button)
        button1.setOnClickListener {
            kaydet(it)
        }

        val resimgoster = view.findViewById<ImageView>(R.id.imageView3)
        resimgoster.setOnClickListener {
            resimsec()
        }
    }

    private fun resimsec() {
        println("resme tıklandı")
        activity?.let {
            if (ContextCompat.checkSelfPermission(
                    it.applicationContext,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // Permission not granted, request it
                ActivityCompat.requestPermissions(
                    it,
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                    1
                )
            } else {
                // Permission already granted, open gallery
                val galeriIntent =
                    Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                startActivityForResult(galeriIntent, 2)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if(requestCode==1){
            if(grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                //izin alındı
                val galeriIntent=Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                startActivityForResult(galeriIntent,2)
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(requestCode == 2 && resultCode == Activity.RESULT_OK && data != null){

            secilenGorsel=data.data

            try{
                context?.let {
                    if(secilenGorsel !=null) {
                        if(Build.VERSION.SDK_INT>=28) {
                            val source=ImageDecoder.createSource(it.contentResolver,secilenGorsel!!)
                            secilenBitmap=ImageDecoder.decodeBitmap(source)
                            val imageView2 = view?.findViewById<ImageView>(R.id.imageView3)
                            imageView2?.setImageBitmap(secilenBitmap)
                            Log.e("GalleryFragment","Görsel zaten ekli")
                        }else{
                            secilenBitmap=MediaStore.Images.Media.getBitmap(it.contentResolver,secilenGorsel)
                            val imageView2 = view?.findViewById<ImageView>(R.id.imageView3)
                            imageView2?.setImageBitmap(secilenBitmap)
                            Log.e("GalleryFragment","Görsel Eklendi")
                        }
                    }
                }
                Log.e("GalleryFragment","Resim Yüklendi")
            }catch (e:Exception){
                e.printStackTrace()
                Log.e("GalleryFragment","Resim Yüklerken Hata oluştu")
            }
        }

        super.onActivityResult(requestCode, resultCode, data)
    }


    fun kaydet(view: View) {
        Log.d("GaleriFragment","Kaydet'e basıldı")

        val yemekadi = view.findViewById<EditText>(R.id.yemekismi)
        val yemekismi = yemekadi.text.toString()

        println("Yemek İsmi="+yemekismi)

        val yemekmalzeme = view.findViewById<EditText>(R.id.yemekmalzeme)
        val yemekmalzemeleri = yemekmalzeme.text.toString()
        println("Yemek malzemeleri="+yemekmalzemeleri)

        val yemektarif = view.findViewById<EditText>(R.id.yemektarifi)
        val yemektarifi=yemektarif.text.toString()
        println("yemektarifi="+yemektarifi)

        if(secilenBitmap != null){
            val kucukBitmap=kucukBitmapOlustur(secilenBitmap!!, maksimumBoyu = 300)
            val outputStream=ByteArrayOutputStream()
            kucukBitmap.compress(Bitmap.CompressFormat.PNG,50,outputStream)
            val byteDizisi=outputStream.toByteArray()


            try{

                context?.let {
                    val database= it.openOrCreateDatabase("Yemekler",Context.MODE_PRIVATE,null)
                    database?.execSQL("CREATE TABLE IF NOT EXISTS yemekler(id INTEGER PRIMARY KEY, yemekismi VARCHAR,yemekmalzemesi VARCHAR,yemektarifi VARCHAR, gorsel BLOB)")

                    val sqlString = "INSERT INTO yemekler (yemekismi, yemekmalzemesi, yemektarifi, gorsel) VALUES ('pirzola', 'aaa','sdfg','dfg0')"

                    val statement=database.compileStatement(sqlString)
                    statement.bindString(1,yemekismi)
                    statement.bindString(2,yemekmalzemeleri)
                    statement.bindString(3,yemektarifi)
                    statement.bindBlob(4,byteDizisi)
                    statement.execute()
                }
            }catch(e:Exception){
                e.printStackTrace()
            }
           //val action = GalleryFragmentDirections.findNavController()//GalleryFragmentDirections.actionGalleryFragmentToHomeFragment()
            //Navigation.findNavController(view).navigate(action)

            //findNavController().navigate(R.id.action_galleryFragment_to_homeFragment)
        }
    }

    fun kucukBitmapOlustur(kullanicininSectigiBitmap:Bitmap,maksimumBoyu:Int):Bitmap{

        var witdh=kullanicininSectigiBitmap.width
        var height=kullanicininSectigiBitmap.height

        val bitmaporani:Double=witdh.toDouble()/height.toDouble()
        if(bitmaporani>1){
            //yatay
            witdh =maksimumBoyu
            val kisaltilmisHeight=witdh/bitmaporani
            height=kisaltilmisHeight.toInt()
        }
        else{
            //dikey
            height =maksimumBoyu
            val kisaltilmisWidth=height/bitmaporani
            witdh=kisaltilmisWidth.toInt()
        }
        return Bitmap.createScaledBitmap(kullanicininSectigiBitmap, witdh, height, true)
       // return Bitmap.createScaledBitmap(kullanicininSectigiBitmap,witdh/2,height/2,true)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
